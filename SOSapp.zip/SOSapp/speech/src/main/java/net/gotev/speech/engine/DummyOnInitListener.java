package net.gotev.speech.engine;

import android.speech.tts.TextToSpeech;

public class DummyOnInitListener implements TextToSpeech.OnInitListener {
    @Override
    public void onInit(int status) {

    }
}
