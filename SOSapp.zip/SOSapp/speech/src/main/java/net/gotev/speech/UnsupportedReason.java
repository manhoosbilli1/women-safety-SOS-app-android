package net.gotev.speech;

public enum UnsupportedReason {
    GOOGLE_APP_NOT_FOUND,
    EMPTY_SUPPORTED_LANGUAGES
}
