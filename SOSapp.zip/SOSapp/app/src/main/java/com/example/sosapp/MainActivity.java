package com.example.sosapp;

import android.Manifest;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.example.sosapp.broadcastreceiver.Restarter;
import com.example.sosapp.db.OnOffDB;
import com.example.sosapp.service.MySpeechService;
import com.example.sosapp.service.VolumeService;

import java.util.ArrayList;
import java.util.List;

import static android.telephony.SmsManager.getDefault;

public class MainActivity extends AppCompatActivity {
    public static final int PERMISSION_ALL = 1;
    private static final String TAG = "SCREEN_TOGGLE_TAG";
    static double lat;
    static double longitude;
    List<String> myList = new ArrayList<String>();
    LocationManager locationManager;
    DatabaseHelper dbHandler;
    OnOffDB onOffDB;
    Intent mServiceIntent, mSpeechIntent;
    Button add, button_location;
    Switch gpsloc;
    SQLiteDatabase checkDB = null;

    String[] PERMISSIONS = new String[]{

            Manifest.permission.SEND_SMS,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.INTERNET,
            Manifest.permission.LOCATION_HARDWARE,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };
    private TextView textView_location;
    private VolumeService mVolumeService;
    private MySpeechService mySpeechService;

    public static boolean hasPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grandResults) {
        // this boolean will tell us that user granted permission or not.
        boolean allowed = true;
        switch (requestCode) {
            case PERMISSION_ALL:
                for (int res : grandResults) {
                    // if user granted all required permissions then 'allowed' will return true.
                    allowed = allowed && (res == PackageManager.PERMISSION_GRANTED);
                }
                break;
            default:
                // if user denied then 'allowed' return false.
                allowed = false;
                break;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (!hasPermissions(this, PERMISSIONS)) {
            ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);
        }

        mVolumeService = new VolumeService();
        mySpeechService = new MySpeechService();

        add = findViewById(R.id.addtocontacts);
        gpsloc = (Switch) findViewById(R.id.gpsloc);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        textView_location = findViewById(R.id.text_location);
        button_location = findViewById(R.id.button_location);
        dbHandler = new DatabaseHelper(MainActivity.this);
        onOffDB = new OnOffDB(MainActivity.this);


        myList = dbHandler.getEveryone();

        try {

            checkDB = new OnOffDB(MainActivity.this).getWritableDatabase();

            if (onOffDB.getStatus(checkDB).equals("0")) {
                gpsloc.setChecked(false);
            } else {
                gpsloc.setChecked(true);
            }

            if (checkDB != null) {
                checkDB.close();
            }
        } catch (SQLiteException e) {

        }

        LocalBroadcastManager.getInstance(this).registerReceiver(
                new BroadcastReceiver() {
                    @Override
                    public void onReceive(Context context, Intent intent) {
                        String status = intent.getStringExtra(VolumeService.STATUS);

                        if (status.equals("0")) {
                            gpsloc.setChecked(false);
                        } else {
                            gpsloc.setChecked(true);
                        }
                    }
                }, new IntentFilter(VolumeService.ACTION_LOCATION_BROADCAST)
        );


        button_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    GPSTracker gpsTracker = new GPSTracker(MainActivity.this);
                    lat = gpsTracker.getLatitude();
                    longitude = gpsTracker.getLongitude();
                    textView_location.setText("Lat: " + lat + ", " + "Lon: " + longitude);
                    Toast.makeText(MainActivity.this, "Fetched location successfully", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this, "Couldn't fetch location", Toast.LENGTH_SHORT).show();
                }
                //checking for permission to send sms
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                        //if (lat != 0.0 && longitude != 0.0)
                        {
                            for (int i = 0; i < myList.size(); i++) {
                                sendSMS(myList.get(i), lat, longitude);
                            }
                            //} else {
                            //  Toast.makeText(MainActivity.this, "Coordinate values zero", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 1);
                    }
                }
            }
        });


        gpsloc.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    try {
                        checkDB = new OnOffDB(MainActivity.this).getWritableDatabase();
                        onOffDB.update(checkDB, "1");

                        if (checkDB != null) {
                            checkDB.close();
                        }
                    } catch (SQLiteException e) {

                    }
                } else {
                    checkDB = new OnOffDB(MainActivity.this).getWritableDatabase();

                    onOffDB.update(checkDB, "0");

                    if (checkDB != null) {
                        checkDB.close();
                    }
                }
            }
        });


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), database.class);
                startActivity(i);
            }
        });

        mServiceIntent = new

                Intent(MainActivity.this, mVolumeService.getClass());
        if (!

                isMyServiceRunning(mVolumeService.getClass())) {
            startService(mServiceIntent);
        }

        mSpeechIntent = new

                Intent(MainActivity.this, mySpeechService.getClass());
        if (!

                isMyServiceRunning(mySpeechService.getClass())) {
            startService(mSpeechIntent);
        }

    }


    public void sendSMS(String num, double lat, double longitude) {
        String msg = "Help! I am in danger" + ". location:" + lat + ", " + longitude;
        try {
            SmsManager smsManager = getDefault();
            smsManager.sendTextMessage(num, null, msg, null, null);
            Toast.makeText(this, this.getString(R.string.smssent), Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, this.getString(R.string.smsnotsent), Toast.LENGTH_SHORT).show();
        }
    }

    //    @Override
//    public boolean onKeyDown(int keyCode, KeyEvent event){
//        int timer;
//
//        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP){
////            if (firsTime){
////                timer = (int) System.currentTimeMillis();
////            }
//            Toast.makeText(this, "Volume Up", Toast.LENGTH_LONG).show();
//
//            return true;
//        }
//
//        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN){
//            Toast.makeText(this, "Volume Down", Toast.LENGTH_LONG).show();
//            return true;
//        }
//
//        return super.onKeyDown(keyCode, event);
//    }
    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                Log.i("isMyServiceRunning?", true + "");
                return true;
            }
        }
        Log.i("isMyServiceRunning?", false + "");
        return false;
    }

    @Override
    protected void onDestroy() {
        //stopService(mServiceIntent);


        Intent broadcastIntent = new Intent();
        broadcastIntent.setAction("restartservice");
        broadcastIntent.setClass(this, Restarter.class);
        this.sendBroadcast(broadcastIntent);
        super.onDestroy();
    }
}