package com.example.sosapp.db;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.io.IOException;

public class OnOffDB extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "onoffdb";
    public static final String CONTACTS_TABLE_NAME = "onoffdb";
    Context c;

    public OnOffDB(Context context) {

        super(context, DATABASE_NAME, null, 1);
        c = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(
                    "create table " + CONTACTS_TABLE_NAME + "(id INTEGER PRIMARY KEY, status text)"
            );
            db.execSQL("INSERT INTO " + CONTACTS_TABLE_NAME + " VALUES('1','0');");


            Toast.makeText(c, db.getPath(), Toast.LENGTH_SHORT).show();

            Log.i("DONE", db.getPath());
        } catch (SQLiteException e) {
            try {
                throw new IOException(e);
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + CONTACTS_TABLE_NAME);
        onCreate(db);
    }


    public String getStatus(SQLiteDatabase db) {
        Cursor res = db.rawQuery("select status from " + CONTACTS_TABLE_NAME + " WHERE id = '1' ", null);
        res.moveToFirst();
        return res.getString(res.getColumnIndex("status"));
    }

    public boolean update(SQLiteDatabase db, String s) {
        db.execSQL("UPDATE " + CONTACTS_TABLE_NAME + " SET status = " + "'" + s + "'" + "WHERE id = " + "'1'");
        return true;
    }
}
