package com.example.sosapp.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteException;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.media.VolumeProviderCompat;

import com.example.sosapp.DatabaseHelper;
import com.example.sosapp.GPSTracker;
import com.example.sosapp.SendSMS;
import com.example.sosapp.broadcastreceiver.Restarter;
import com.example.sosapp.db.OnOffDB;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class VolumeService extends Service {

    private static final String TAG = "VOLUME";
    public int counter = 0;
    SendSMS sendSMS;
    List<String> myList = new ArrayList<String>();
    DatabaseHelper dbHandler;
    OnOffDB helper;

    double lat;
    double longitude;
    private MediaSessionCompat mediaSession;
    private Timer timer;
    private TimerTask timerTask;

    int vu_1 = 0, vu_2 = 0;
    int vd_1 = 0, vd_2 = 0;
    int vu = 0, vd = 0;


    @Override
    public void onCreate() {
        super.onCreate();

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.O)
            startMyOwnForeground();
        else
            startForeground(1, new Notification());
        Context c = this;
        mediaSession = new MediaSessionCompat(this, "ValidateVolumeKeyService");
        mediaSession.setFlags(MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS |
                MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS);
        mediaSession.setPlaybackState(new PlaybackStateCompat.Builder()
                .setState(PlaybackStateCompat.STATE_PLAYING, 0, 0) //you simulate a player which plays something.
                .build());

        final long[] startTime = {0};

        VolumeProviderCompat myVolumeProvider =
                new VolumeProviderCompat(VolumeProviderCompat.VOLUME_CONTROL_RELATIVE, /*max volume*/100, /*initial volume level*/50) {
                    @Override
                    public void onAdjustVolume(int direction) {

                        long elapsed = (System.nanoTime() - startTime[0]) / 1000000;
                        if (elapsed > 3000) {
                            vu_1 = 0;
                            vu_2 = 0;
                            vd_1 = 0;
                            vd_2 = 0;
                            vu = 0;
                            vd = 0;
                            startTime[0] = System.nanoTime();
                        }

                        if (direction == -1) {
                            Log.i(TAG, "onAdjustVolume: VOLUME DOWN");
                            vd += 1;
                        }
                        if (direction == 1) {
                            Log.i(TAG, "onAdjustVolume: VOLUME UP");
                            vu += 1;

                        }
                        if (direction == 0) {
                            Log.i(TAG, "onAdjustVolume: VOLUME RELEASE");


                            if (vu == 1 && vu_1 == 0 && vu_2 == 0 && vd_1 == 0 && vd_2 == 0) {
                                vu_1 = 1;
                            } else if (vu == 2 && vu_1 == 1 && vu_2 == 0 && vd_1 == 1 && vd_2 == 0) {
                                vu_2 = 1;
                            } else if (vu > 2) {
                                vu = 0;
                            } else if (vd == 1 && vu_1 == 1 && vu_2 == 0 && vd_1 == 0 && vd_2 == 0) {
                                vd_1 = 1;
                            } else if (vd == 2 && vu_1 == 1 && vu_2 == 1 && vd_1 == 1 && vd_2 == 0) {
                                vd_2 = 1;
                            } else if (vd > 2) {
                                vd = 0;
                            }


                        }

                        if (vd_1 == 1 && vd_2 == 1 && vu_1 == 1 && vu_2 == 1) {
                            vu_1 = 0;
                            vu_2 = 0;
                            vd_1 = 0;
                            vd_2 = 0;
                            vu = 0;
                            vd = 0;

                            new Handler(Looper.getMainLooper()).post(new Runnable() {
                                @Override
                                public void run() {
                                    executeCommand(c);
                                }
                            });
                        }
                    }
                };

        mediaSession.setPlaybackToRemote(myVolumeProvider);
        mediaSession.setActive(true);
    }

    OnOffDB onOffDB;
    public static final String ACTION_LOCATION_BROADCAST = VolumeService.class.getName() + "LocationBroadcast", STATUS = "0";


    private void sendBroadcastMessage() {

        try {
            Intent intent = new Intent(ACTION_LOCATION_BROADCAST);
            intent.putExtra(STATUS, "1");
            LocalBroadcastManager.getInstance(this).sendBroadcast(intent);


        } catch (SQLiteException e) {
        }
    }

    private void executeCommand(Context context) {
        sendSMS = new SendSMS();
        dbHandler = new DatabaseHelper(context);
        myList = dbHandler.getEveryone();

        try {
            sendBroadcastMessage();
            GPSTracker gpsTracker = new GPSTracker(context);
            lat = gpsTracker.getLatitude();
            longitude = gpsTracker.getLongitude();
            Toast.makeText(context, "Fetched location successfully", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(context, "Couldn't fetch location", Toast.LENGTH_SHORT).show();
        }
        //checking for permission to send sms
        //if (lat != 0.0 && longitude != 0.0)
        //{
        for (int i = 0; i < myList.size(); i++) {
            sendSMS.sendSMS(myList.get(i), lat, longitude, context);
            //  }
            //}
            //else
            // {
            //Toast.makeText(VolumeService.this, "Coordinate values zero", Toast.LENGTH_SHORT).show();
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private void startMyOwnForeground() {
        String NOTIFICATION_CHANNEL_ID = "example.permanence";
        String channelName = "Background Service";

        NotificationChannel chan = new NotificationChannel(NOTIFICATION_CHANNEL_ID, channelName, NotificationManager.IMPORTANCE_NONE);
        chan.setLightColor(Color.BLUE);
        chan.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);

        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        assert manager != null;
        manager.createNotificationChannel(chan);

        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID);
        Notification notification = notificationBuilder.setOngoing(true)
                .setContentTitle("App is running in background")
                .setPriority(NotificationManager.IMPORTANCE_MIN)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build();
        startForeground(2, notification);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        //startTimer();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stoptimertask();

        Intent broadcastIntent = new Intent();
        broadcastIntent.setAction("restartservice");
        broadcastIntent.setClass(this, Restarter.class);
        this.sendBroadcast(broadcastIntent);
    }

    public void startTimer() {
        timer = new Timer();
        timerTask = new TimerTask() {
            public void run() {
                Log.i("Count", "=========  " + (counter++));
            }
        };
        timer.schedule(timerTask, 1000, 1000); //
    }

    public void stoptimertask() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
