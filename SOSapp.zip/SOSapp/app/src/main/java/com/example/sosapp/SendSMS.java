package com.example.sosapp;

import android.content.Context;
import android.telephony.SmsManager;
import android.widget.Toast;

import static android.telephony.SmsManager.getDefault;

public class SendSMS {
    public void sendSMS(String num, double lat, double longitude, Context context) {
        String msg = "Help! I am in danger" + ". location:" + lat + ", " + longitude;
        try {
            SmsManager smsManager = getDefault();
            smsManager.sendTextMessage(num, null, msg, null, null);
            Toast.makeText(context, context.getString(R.string.smssent), Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(context, context.getString(R.string.smsnotsent), Toast.LENGTH_SHORT).show();
        }
    }

}
